import { GoogleGenAI } from "@google/genai";
import { BANGBOO_STYLE_PROMPT } from '../constants';

const getAiClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found");
  }
  return new GoogleGenAI({ apiKey });
};

/**
 * Step 1: Analyze the user image and generate a text prompt describing the Bangboo version.
 */
export const analyzeAndCreatePrompt = async (
  base64Image: string,
  mimeType: string,
  mood: string
): Promise<string> => {
  const ai = getAiClient();
  
  // Refine prompt based on selected mood
  let moodInstruction = "";
  if (mood !== 'default') {
    moodInstruction = `The character should have a strictly ${mood} expression and posture.`;
  }

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: mimeType,
            data: base64Image
          }
        },
        {
          text: `${BANGBOO_STYLE_PROMPT} \n ${moodInstruction}`
        }
      ]
    }
  });

  const promptText = response.text;
  if (!promptText) throw new Error("Failed to generate prompt analysis.");
  
  return promptText;
};

/**
 * Step 2: Generate the actual image using the prompt from Step 1.
 */
export const generateBangbooImage = async (prompt: string): Promise<string> => {
  const ai = getAiClient();

  // We use the pro-image-preview for high quality textures suitable for "Bangboo" aesthetics
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: {
      parts: [
        {
          text: prompt + " , 4k resolution, unreal engine 5 render, highly detailed, octane render, trending on artstation, masterpiece, studio lighting, plain dark background"
        }
      ]
    },
    config: {
      imageConfig: {
        aspectRatio: "1:1",
        imageSize: "1K" // 1K is standard for this model
      }
    }
  });

  // Extract image from response parts
  if (response.candidates?.[0]?.content?.parts) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData && part.inlineData.data) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
  }

  throw new Error("No image data generated.");
};
