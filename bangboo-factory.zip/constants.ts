export const BANGBOO_STYLE_PROMPT = `
  Analyze the uploaded image carefully. Your task is to reimagine the subject (person, animal, or object) as a "Bangboo" character from the game Zenless Zone Zero.
  
  KEY VISUAL TRAITS OF A BANGBOO:
  1. Anatomy: Small, stout, cylindrical/bean-shaped robotic body. Short, stubby legs and arms.
  2. Head: The "face" is integrated into the rounded top of the body, usually featuring a black digital screen showing glowing eyes (often emojis or simple shapes).
  3. Ears: Two long, rabbit-like mechanical ears on top. These often act as handles or sensors.
  4. Texture: High-quality matte plastic, metal joints, slightly worn industrial look (scratches, stickers).
  5. Aesthetic: Cyberpunk, streetwear, industrial mascot.
  
  INSTRUCTIONS:
  - Identify the key colors, clothing, and distinctive features of the user's image.
  - Translate these features onto the Bangboo body. 
  - If the user is human, turn their outfit into the Bangboo's "skin" or casing paint job. 
  - If they wear glasses, put digital glasses on the screen face or physical goggles.
  - Maintain the mood of the original image.
  
  OUTPUT FORMAT:
  Return ONLY a detailed image generation prompt. Do not add conversational text. The prompt should start with: "A high-quality 3D render of a custom Bangboo character from Zenless Zone Zero..."
`;

export const MOOD_OPTIONS = [
  { id: 'default', label: 'Original Match', icon: '😐' },
  { id: 'happy', label: 'Hyper Happy', icon: '😆' },
  { id: 'grumpy', label: 'Grumpy/Serious', icon: '😠' },
  { id: 'combat', label: 'Combat Ready', icon: '⚔️' },
  { id: 'lazy', label: 'Lazy/Sleepy', icon: '💤' },
];
